package com.example.hospitalfinder.dummy;

public interface ISimpleFragment {
}
