package com.example.hospitalfinder

const val LOG_TAG = "hospitalLogging"