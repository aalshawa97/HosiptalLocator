package com.example.hospitalfinder

import androidx.lifecycle.ViewModel

class MedicineViewModel : ViewModel() {
    // TODO: Implement the ViewModel

}