package com.example.hospitalfinder.dummy;

import androidx.fragment.app.Fragment;

public class SimpleFragment extends Fragment implements ISimpleFragment {

    public SimpleFragment() {
        // Required empty public constructor
    }

//        fun PlaceSelectionListener()
//        {
//
//        }

    }

//    @Override
//    public View onCreateView(LayoutInflater inflater,
//                             ViewGroup container, Bundle savedInstanceState) {
//        // Inflate the layout for this fragment
//        return inflater.inflate(R.layout.fragment_simple,
//                container, false);