package com.example.hospitalfinder

import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
//class MainViewModel:ViewModel(app: Application) :AndroidView(app){
//    // TODO: Implement the ViewModel
//    init{
//    val text = FileHelper.getTextFromResources(app, R.raw.hospital_data)
//    Log.i(tag:LOG_TAG, text)

    //fun parseText(text: String){
//        val moshi = Moshi.Builder().build()
//        val adapter:JsonAdapter<List<Monster>> = moshi.adapter(listType)
//// }
//}