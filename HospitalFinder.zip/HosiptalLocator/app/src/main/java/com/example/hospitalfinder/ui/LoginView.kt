package com.example.hospitalfinder.ui

import UserViewModel
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.hospitalfinder.R

class LoginView:Fragment(){
    private lateinit var viewModel: UserViewModel

//    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View?{
//        return inflater.inflate(R.layout.fragment_login, container, attachToRoot:false)
//    }
}
