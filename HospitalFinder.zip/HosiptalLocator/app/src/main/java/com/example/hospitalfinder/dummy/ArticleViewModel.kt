package com.example.hospitalfinder.dummy

import androidx.lifecycle.ViewModel

class ArticleViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}